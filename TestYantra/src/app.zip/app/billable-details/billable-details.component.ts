import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billable-details',
  templateUrl: './billable-details.component.html',
  styleUrls: ['./billable-details.component.css']
})
export class BillableDetailsComponent implements OnInit {
  clients: any;

  constructor() { 
this.getBillable();

  }

  getBillable() {
    let getmyVal: any = JSON.parse(localStorage.getItem("billables"));
    console.log('details in billables::', getmyVal);
    this.clients = getmyVal;
    console.log(this.clients.listBill);
    this.clients = this.clients.listBill;
  }

  ngOnInit() {
    
  }

}
